package implementaciones;

import java.util.*;
import java.util.function.Function;
import java.util.function.Supplier;

public class Rectangulador {



	/**
	 * Calcula el numero de rectangulos distintos que se pueden
	 * formar con varios elementos. Se considera que el rectangulo
	 * 5x7 y el rectangulo 7x5 son iguales. No se considera rectangulos
	 * a los que tienen lado 1.
	 *
	 * @param i numero de elementos
	 * @return el numero de rectangulos diferentes que se pueden
	 *         formar con este numero de elementos
	 * @throws IllegalArgumentException Si el número es 0 o negativo
	 */
	public static long rectangulosDiferentes(long i) {
		return rectangulosDiferentesHacker(i);
	}

	public static long rectangulosDiferentesLamer(long i) {
		if (i <= 0) throw new IllegalArgumentException();
		long count = 0;
		long limit = (long) Math.sqrt(i);
		for (long a = 2; a <= limit; a++) {
			if (i % a == 0) {
				long b = i / a;
				if (b >= 2) {
					// contamos cada par (a,b) con a<=b exactamente una vez
					count++;
				}
			}
		}

		return count;
	}

	public static long rectangulosDiferentesHacker(long i) {
		if( i <= 0 ) throw new IllegalArgumentException();
		final var factores = factoresDe(i);
		final var mapa = mapaDeFactores(factores);
		//System.out.println("Factores de " + i + ": " + factores + " Mapa: " + mapa);
		long count = 1;
		boolean alExponentesPares = true;
		for ( var factor : mapa.keySet() ) {
			int exponent = mapa.get(factor);
			if( exponent % 2 != 0 ) {
				alExponentesPares = false;
			}
			count *= (exponent + 1);
		}
		if( alExponentesPares )
			return count/2;
		else
			return count/2 - 1;
	}


	private static ArrayList<Long> factoresDe(long i) {
		var factores = new ArrayList<Long>();
		long numeroRestante = i;
		while ( numeroRestante % 2 == 0 ) {
			factores.add(2L);
			numeroRestante /= 2;
		}
		for( var posibleFactor = 3L; posibleFactor <= Math.sqrt(numeroRestante)+1L; posibleFactor += 2 ) {
			while ( numeroRestante % posibleFactor == 0 ) {
				factores.add(posibleFactor);
				numeroRestante /= posibleFactor;
			}
		}
		if( numeroRestante != 1L){
			factores.add(numeroRestante);
		}
		return factores;
	}

	public static Map<Long,Integer> mapaDeFactores(ArrayList<Long> factores) {
		var mapa = new HashMap<Long,Integer>();
		for ( var factor : factores ) {
			if ( !mapa.containsKey(factor) )
				mapa.put(factor, 1);
			else
				mapa.put(factor, mapa.get(factor)+1);
		}
		return mapa;
	}

	static long[] timer( Function<Long,Long> f, long arg ) {
		long inicio = System.currentTimeMillis();
		long ret = f.apply(arg);
		long millis = System.currentTimeMillis() - inicio;
		//System.out.println("Tiempo: " + millis + "ms para el numero: " + arg + " con resultado: " + ret);
		return new long[]{millis, ret, arg };
	}

	public static void main(String[] args) {
		//pruebaComparativa();

		var grandes = new long[] {
				3L*5*5*5*5*5*5*5*5*5*5*5*5*5*5*5*5*5*5*5*5*5*5*5*5*5*5*5,
				2L*3*3*3*3*3*3*3*3*3*3*3*3*3*3*3*3*3*3*3*3*3*3*3*3*3*33*3*3*3*3*3*3*3*3*3*3,
				2L*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2*3,
				Long.MAX_VALUE,
				9223372036854775801L,
				//9223372036854775801L,
				//9223372036854775804L
		};

/*
		var hackers = Arrays.stream(grandes).
				mapToObj( (var grande) -> timer(Rectangulador::rectangulosDiferentesHacker, grande) ).
				toArray();
		System.out.println(hackers);

		var lamers = Arrays.stream(grandes).
				mapToObj( (var grande) -> timer(Rectangulador::rectangulosDiferentesLamer, grande)).
				toArray();

		System.out.println(lamers);
*/

		for ( var grande : grandes ) {
			System.out.println(grande);
			var lamer = timer( Rectangulador::rectangulosDiferentesLamer, grande );
			var hacker = timer( Rectangulador::rectangulosDiferentesHacker, grande );
			System.out.println( "lamer: " + lamer[0] + "ms\t hacker: " + hacker[0] + "ms\t para el numero: " + grande );
			assert( hacker[1] == lamer[1] );
		}
	}

	private static void pruebaComparativa() {
		for( int i = 1; i <= 100000000; i++ ) {
			long a = rectangulosDiferentesLamer(i);
			long b = rectangulosDiferentesHacker(i);
			if (i % 1000 == 0){
				System.out.print(".");
				System.out.flush();
			}
			if( a != b ) {
				System.out.println(a + "\t\t" + b + "********************************");
				System.exit(0);
			}
		}
	}
}
