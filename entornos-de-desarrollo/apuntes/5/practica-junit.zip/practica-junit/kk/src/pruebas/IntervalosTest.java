package pruebas;

import static org.junit.Assert.*;
import org.junit.Test;
import implementaciones.Intervalos;


/**
 * Pruebas para el ejercicio de Intervalos
 *
 * Cada test probará solo un caso, y se indicará claramente en el nombre del test lo que se está probando.
 * Se pueden añadir tantos tests como sea necesario para cubrir todos los caminos posibles
 *
 * @autor Tu nombre aquí
 */
public class IntervalosTest {

    @Test
    public void testDelJavadoc() {
        var solapamiento = Intervalos.solapamiento( 5,10,0, 9);
        assertEquals(4,solapamiento);
    }
}
