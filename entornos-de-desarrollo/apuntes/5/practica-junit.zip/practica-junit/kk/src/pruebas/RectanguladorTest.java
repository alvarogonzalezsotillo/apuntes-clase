package pruebas;

import static org.junit.Assert.*;
import org.junit.Test;
import implementaciones.Rectangulador;


public class RectanguladorTest {

	@Test
	public void unPrimoNoTieneRectangulos(){
		assertEquals( Rectangulador.rectangulosDiferentes(29), 0 );
	}
	
	@Test
	public void soloUnRectangulo(){
		assertEquals( Rectangulador.rectangulosDiferentes(391), 1 );
	}

	@Test
	public void soloUnRectanguloCuadrado(){
		assertEquals( Rectangulador.rectangulosDiferentes(11*11), 1 );
	}
	
	
	@Test
	public void variosRectangulos(){
		assertEquals( Rectangulador.rectangulosDiferentes(60), 5 );
		assertEquals( Rectangulador.rectangulosDiferentes(3838293), 3 );
		assertEquals( Rectangulador.rectangulosDiferentes(2834214), 3 );
		assertEquals( Rectangulador.rectangulosDiferentes(600000000), 89 );
	}


	@Test
	public void variosRectangulosGrandes(){
		assertEquals( Rectangulador.rectangulosDiferentes(60000), 29 );
	}

	@Test(expected=IllegalArgumentException.class)
	public void elCeroNoTieneRectangulos(){
		Rectangulador.rectangulosDiferentes(0);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void unNegativoNoTieneRectangulos(){
		Rectangulador.rectangulosDiferentes(-60);
	}
	
	@Test(timeout=1000)
	public void unNumeroGrande1(){
		assertEquals( Rectangulador.rectangulosDiferentes(9223372036854775801L ), 3);
	}

	@Test(timeout=1000)
	public void unNumeroGrande2(){
		assertEquals( Rectangulador.rectangulosDiferentes(9223372036854775807L ), 47);
	}

	@Test(timeout=1000)
	public void unNumeroGrande3(){
		assertEquals( Rectangulador.rectangulosDiferentes(3904997717061932759L ), 1);
	}

}
