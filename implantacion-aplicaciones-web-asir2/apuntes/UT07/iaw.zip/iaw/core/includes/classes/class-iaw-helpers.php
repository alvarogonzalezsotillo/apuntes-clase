<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Class Iaw_Helpers
 *
 * This class contains repetitive functions that
 * are used globally within the plugin.
 *
 * @package		IAW
 * @subpackage	Classes/Iaw_Helpers
 * @author		Alumno
 * @since		1.0.0
 */
class Iaw_Helpers{

	/**
	 * ######################
	 * ###
	 * #### CALLABLE FUNCTIONS
	 * ###
	 * ######################
	 */

}
