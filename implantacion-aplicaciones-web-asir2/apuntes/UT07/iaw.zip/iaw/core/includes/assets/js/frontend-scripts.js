/*------------------------- 
Frontend related javascript
-------------------------*/

