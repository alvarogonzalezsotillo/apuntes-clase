<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! class_exists( 'Iaw' ) ) :

	/**
	 * Main Iaw Class.
	 *
	 * @package		IAW
	 * @subpackage	Classes/Iaw
	 * @since		1.0.0
	 * @author		Alumno
	 */
	final class Iaw {

		/**
		 * The real instance
		 *
		 * @access	private
		 * @since	1.0.0
		 * @var		object|Iaw
		 */
		private static $instance;

		/**
		 * IAW helpers object.
		 *
		 * @access	public
		 * @since	1.0.0
		 * @var		object|Iaw_Helpers
		 */
		public $helpers;

		/**
		 * IAW settings object.
		 *
		 * @access	public
		 * @since	1.0.0
		 * @var		object|Iaw_Settings
		 */
		public $settings;

		/**
		 * Throw error on object clone.
		 *
		 * Cloning instances of the class is forbidden.
		 *
		 * @access	public
		 * @since	1.0.0
		 * @return	void
		 */
		public function __clone() {
			_doing_it_wrong( __FUNCTION__, __( 'You are not allowed to clone this class.', 'iaw' ), '1.0.0' );
		}

		/**
		 * Disable unserializing of the class.
		 *
		 * @access	public
		 * @since	1.0.0
		 * @return	void
		 */
		public function __wakeup() {
			_doing_it_wrong( __FUNCTION__, __( 'You are not allowed to unserialize this class.', 'iaw' ), '1.0.0' );
		}

		/**
		 * Main Iaw Instance.
		 *
		 * Insures that only one instance of Iaw exists in memory at any one
		 * time. Also prevents needing to define globals all over the place.
		 *
		 * @access		public
		 * @since		1.0.0
		 * @static
		 * @return		object|Iaw	The one true Iaw
		 */
		public static function instance() {
			if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Iaw ) ) {
				self::$instance					= new Iaw;
				self::$instance->base_hooks();
				self::$instance->includes();
				self::$instance->helpers		= new Iaw_Helpers();
				self::$instance->settings		= new Iaw_Settings();

				//Fire the plugin logic
				new Iaw_Run();

				/**
				 * Fire a custom action to allow dependencies
				 * after the successful plugin setup
				 */
				do_action( 'IAW/plugin_loaded' );
			}

			return self::$instance;
		}

		/**
		 * Include required files.
		 *
		 * @access  private
		 * @since   1.0.0
		 * @return  void
		 */
		private function includes() {
			require_once IAW_PLUGIN_DIR . 'core/includes/classes/class-iaw-helpers.php';
			require_once IAW_PLUGIN_DIR . 'core/includes/classes/class-iaw-settings.php';

			require_once IAW_PLUGIN_DIR . 'core/includes/classes/class-iaw-run.php';
		}

		/**
		 * Add base hooks for the core functionality
		 *
		 * @access  private
		 * @since   1.0.0
		 * @return  void
		 */
		private function base_hooks() {
			add_action( 'plugins_loaded', array( self::$instance, 'load_textdomain' ) );
		}

		/**
		 * Loads the plugin language files.
		 *
		 * @access  public
		 * @since   1.0.0
		 * @return  void
		 */
		public function load_textdomain() {
			load_plugin_textdomain( 'iaw', FALSE, dirname( plugin_basename( IAW_PLUGIN_FILE ) ) . '/languages/' );
		}

	}

endif; // End if class_exists check.