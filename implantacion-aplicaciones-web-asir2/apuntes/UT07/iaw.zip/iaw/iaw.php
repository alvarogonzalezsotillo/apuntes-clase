<?php
/**
 * IAW
 *
 * @package       IAW
 * @author        Alumno
 * @version       1.0.0
 *
 * @wordpress-plugin
 * Plugin Name:   IAW
 * Plugin URI:    https://iaw.iesavellaneda.es
 * Description:   Plantilla para hacer plugin de wordpress, con pluginplate.com
 * Version:       1.0.0
 * Author:        Alumno
 * Author URI:    https://your-author-domain.com
 * Text Domain:   iaw
 * Domain Path:   /languages
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) exit;
// Plugin name
define( 'IAW_NAME',			'IAW' );

// Plugin version
define( 'IAW_VERSION',		'1.0.0' );

// Plugin Root File
define( 'IAW_PLUGIN_FILE',	__FILE__ );

// Plugin base
define( 'IAW_PLUGIN_BASE',	plugin_basename( IAW_PLUGIN_FILE ) );

// Plugin Folder Path
define( 'IAW_PLUGIN_DIR',	plugin_dir_path( IAW_PLUGIN_FILE ) );

// Plugin Folder URL
define( 'IAW_PLUGIN_URL',	plugin_dir_url( IAW_PLUGIN_FILE ) );

/**
 * Load the main class for the core functionality
 */
require_once IAW_PLUGIN_DIR . 'core/class-iaw.php';

/**
 * The main function to load the only instance
 * of our master class.
 *
 * @author  Alumno
 * @since   1.0.0
 * @return  object|Iaw
 */
function IAW() {
	return Iaw::instance();
}

IAW();
